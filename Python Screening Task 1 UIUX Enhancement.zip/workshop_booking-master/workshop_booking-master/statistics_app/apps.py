from django.apps import AppConfig


class StatisticsAppConfig(AppConfig):
    name = 'statistics_app'
