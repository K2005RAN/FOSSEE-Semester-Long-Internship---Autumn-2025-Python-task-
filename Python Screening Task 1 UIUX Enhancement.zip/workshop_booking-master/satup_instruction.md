# Guide to install and get this website running

### Follow below given Steps to get started
> __NOTE__: Use Python3
1. Clone this repo.
    > git clone https://github.com/K2005RAN/FOSSEE-Semester-Long-Internship---Autumn-2025-Python-task-

2. Create a virtual environment and install all the required packages from requirements.txt
    > pip install -r requirements.txt 

3. Make Migrations and Migrate
    > python manage.py makemigrations\
    > python manage.py migrate

4. Create Super User
    > python manage.py createsuperuser

5. Start Server
    > python manage.py runserver

6. Goto admin page and login using superuser credentials
    > localhost:8000/admin

7. Goto Groups and create one group called __instructor__ and give it all permissions.

8. By default when a user signs up, he is given the coordinator position, via the admin panel make the required users profile position instructor and add him/her in instructor group along with the required permissions.

9. Under *settings.py* file ensure that all necessary variables are provided then you're good to go!

### Instructor specific steps

1. An instructor can create workshops according to his/her availability in __Create Workshop__ tab.

2. Instructor can view month wise workshop number, future workshop etc. under Statistics > Workshop Statistics

3. Instructors can view and add comments on coordinator's profile from Profile Statistics or Workshop Status page.

### Coordinator specific steps

1. A coordinator can send workshop proposal as per his/her own convenience under Workshops > Propose a Workshop option.
